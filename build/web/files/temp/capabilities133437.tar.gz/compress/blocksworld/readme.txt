Blocksworld
--------------

In the blocksworld coloured blocks are
stacked on a table. 

This example only consists of a single agent
(Blocksworld.agent.xml), which has an internal
representation of the blocksworld.
When the agent is started, a window is opened
that shows the current state of the blocksworld,
and another panel where you can construct a desired
target configuration.
When the "create goal" button is clicked, the agent
tries to achieve the target configuration by restacking
blocks on the table.

