package jadex.bdi.examples.marsworld_classic;

/**
 *  Java class for ontology mars_beans.
 */
public class MarsOntology
{
	//-------- constants --------

	/** The name of the ontology. */
	public static final String	ONTOLOGY_NAME	= "mars_beans";
}

