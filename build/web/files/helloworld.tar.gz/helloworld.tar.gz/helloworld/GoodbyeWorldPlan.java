package jadex.bdi.examples.helloworld;

import jadex.bdi.runtime.Plan;


/**
 *  The plan body.
 */
public class GoodbyeWorldPlan extends Plan
{
	/**
	 *  The plan body.
	 */
	public void body()
	{
		System.out.println("Goodbye World!");
	}
	
}
