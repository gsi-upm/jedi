Hunter Prey
--------------

To start the example application start
the manager agent.

Szenario:
Two kinds of creatures live on a grid world.
Hunters try to catch the prey, while prey
moves around looking for food.

